package com.gupaoedu.kafka;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.Match;

/**
 * 腾讯课堂搜索【咕泡学院】
 * 官网：www.gupaoedu.com
 * 风骚的Mic 老师
 * create-date: 2019/8/18-21:04
 */
public class Test {

    public static void main(String[] args) {
        //17
        System.out.println(Math.abs("gp-gid3".hashCode())%50);
    }
}
